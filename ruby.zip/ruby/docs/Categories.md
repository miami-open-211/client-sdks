# SwaggerClient::Categories

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Each location must have a unique identifier | [optional] 


